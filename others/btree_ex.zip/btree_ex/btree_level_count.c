/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_level_count.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wiferrei <wiferrei@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/24 15:04:20 by wiferrei          #+#    #+#             */
/*   Updated: 2024/01/24 15:25:37 by wiferrei         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"

int	btree_level_count(t_btree *root)
{
	int	left;
	int	right;

	// If the tree is empty, the height is 0
	if (root == NULL)
		return (0);
	
    // Recursively calculate the height of the left subtree
	left = btree_level_count(root->left);
	// Recursively calculate the height of the right subtree
	right = btree_level_count(root->right);

	// If the left subtree is taller than the right subtree
    if (left > right)
        // The height of the tree is the height of the left subtree plus 1
        return (left + 1);
    else
        // Otherwise, the height of the tree is the height of the right subtree plus 1
        return (right + 1);
}
