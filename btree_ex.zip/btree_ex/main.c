#include "ft_btree.h"

int	main(void)
{
	t_btree	*root;
	char	*search_item;
	void	*found_item;

	root = btree_create_node("root");
	root->left = btree_create_node("left");
	root->right = btree_create_node("right");

	// Preorder Traversal of Binary Tree
	printf("In prefix order:\n");
	btree_apply_prefix(root, print_item);
	printf("\n");

	// Inorder Traversal of Binary Tree
	printf("In infix order:\n");
	btree_apply_infix(root, print_item);
	printf("\n");

	// Postorder Traversal of Binary Tree
	printf("In suffix order:\n");
	btree_apply_suffix(root, print_item);
	printf("\n");

	// Inserting a node in a Binary Search Tree
	// printf("Inserting a node in a Binary Search Tree:\n");
	// btree_insert_data(&root, "new", (int (*)(void *, void *))strcmp);
	// btree_apply_prefix(root, print_item);
	// printf("\n");

	// Search for an item in the Binary Search Tree
	printf("Searching for an item in the Binary Search Tree:\n");
	search_item = "new";
	found_item = btree_search_item(root, search_item, (int (*)(void *, void *))strcmp);
	
	// Check if the item was found or not
	if (found_item != NULL)
		printf("Item '%s' found!\n", (char *)found_item);
	else
		printf("Item '%s' not found.\n", search_item);

	// Count the number of levels in the Binary Search Tree
	printf("\nCounting the number of levels in the Binary Search Tree:\n");
	printf("Number of levels: %d\n", btree_level_count(root));

	// Free the memory allocated for the Binary Search Tree
	free(root->left);
	free(root->right);
	free(root);
	return (0);
}
