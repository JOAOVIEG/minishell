/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_search_item.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wiferrei <wiferrei@student.42lisboa.com    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/24 14:36:56 by wiferrei          #+#    #+#             */
/*   Updated: 2024/01/24 14:47:34 by wiferrei         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"


void *btree_search_item(t_btree *root, void *data_ref, int (*cmpf)(void *, void *))
{
	void *item;

	// Base case: If the current node is NULL, return NULL
	item = NULL;
	if (root != NULL)
	{
		// Recursively search in the left subtree
		item = btree_search_item(root->left, data_ref, cmpf);

		// If the item is not found in the left subtree and the current node's item
		// matches the data reference, return the current item
		if (item == NULL && cmpf(root->item, data_ref) == 0)
			return (root->item);
		
		// If the item is still not found, recursively search in the right subtree
		if (item == NULL)
			item = btree_search_item(root->right, data_ref, cmpf);
	}

	// Return the found item (or NULL if not found)
	return (item);
}


